<?php

    include "header.php";

?>

<table>
    <th>ID</th>
    <th>Nom</th>
    <th>L'email</th>
    <th>Date</th>

<?php

    $host               = "localhost";
    $user               = "root";
    $password      = "";
    $dbName       = "hospital";

    $conn = mysqli_connect($host, $user, $password,$dbName);

    // njib el infos mn bdd

    $query = "SELECT * FROM patients";
    $result = mysqli_query($conn,$query);

    if ($result){
        while($row = mysqli_fetch_assoc($result)){
            echo "<tr><td>" . $row['id'] . "</td><td>" . $row['name'] . "</td><td>" . $row['email'] . "</td><td>" . $row['date'] . "</td></tr>";
        }
        echo "</table>";
    }
    else{
        echo "Keyna xi falta";
    }


?>

