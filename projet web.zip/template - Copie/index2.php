<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Poppins:wght@400;500&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="css1/style2.css">
    <link rel="stylesheet" href="css1/JannaLTRegular.css">
    <link rel="stylesheet" href="css1/style1.css">
    
    <title>spetareka</title>
</head>

<body>

    <header class="main-head">
        <nav>
            <h1 id="logo">Eka Hospital</h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php">About us</a></li>
                <li><a href="#servis">Nos services</a></li>
            </ul>
        </nav>
    </header>

    <section class="hero">
    <div class="main">
        <div class="logo">
            <img src="images/logo.png">
            <h2>EKA Hospital</h2>
        </div>
        <div class="book">
            <p>Bienvenue</p>
            <form action="index2.php" method="post">
                <input type="text" placeholder="VOTRE NOM ET PRENOM" name="name"/>
                <input type="text" placeholder="VOTRE ADRESSE" name="email"/>
                <input type="date" name="date"/>
                <input type="submit" value="Reserver" name="send"/>
            </form>

            <?php

            //cnx mea server 
            $host               = "localhost";
            $user               = "root";
            $password      = "";
            $dbName       = "hospital";
        
            $conn = mysqli_connect($host, $user, $password,$dbName);

            //nsifet les infos li dakhlin lbdd

                $pName          = $_POST['name'];
                $pEmail           = $_POST['email'];
                $pDate            = $_POST['date'];
                $pSend            = $_POST['send'];

            
                if($pSend){
                    $query = "INSERT INTO patients(name,email,date) VALUE('$pName ','$pEmail ','$pDate ')";
                    $result = mysqli_query($conn,$query);
                    echo "<p style='color:green'>" . "REZERVETI" . "</p>";
                }
                else{
                    echo "<p style='color:red'>" . "MAZAL MAREZERVETI" . "</p>";
                }


            ?>


        </div>
    </div>
    </section>




</body>

</html>