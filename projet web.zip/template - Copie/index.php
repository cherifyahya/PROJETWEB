<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/vendors/bootstrap.css">
    <link rel="stylesheet" href="css/vendors/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>

<body>

    <!--header-->
    <header>
        <div class="container">
            <div class="row">

                <!--bars icon-->
                <i class="icon fa fa-bars fa-2x"></i>

                <!--logo-->
                <div class="col-md-3 col-xs-12">
                    <div class="logo">
                        <h2>EKA</h2>
                    </div>
                </div>
                <!--nav-->
                <nav class="col-md-9 col-xs-12">
                    <ul class="nav-list">
                        <li class="list"><a href="">Home</a></li>
                        <li class="list"><a href="#about">About us</a></li>
                        <li class="list"><a href="#servis">Nos services</a></li>

                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!--/header-->

    <!--home-->
    <section class="section home text-center">
        <div class="overlay">
            <div class="container">
                <div class="home-content">
                    <h3 class="home-title">Bienvenue chez EKA Hospital</h3>
                    <p class="lead home-desc">
                    Nous sommes là pour vous
                    </p>

                    <button class="btn button"><a href="index2.php">reserver</a></button>
                </div>
            </div>
        </div>
    </section>
    <!--/home-->

    <!--about us -->
    <section class="sections about">
        <div id="about">
            <div class="container">
                <div class="section-header text-center">
                    <h2 class="section-title">About us</h2>
                    <div class="line"><span></span></div>
                    <p>Qui sommes-nous?<br/>who are we?</p>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="about-info">
                            <h3>Welcome to <span>Eka</span> Hospital</h3>
                            <p class="about-info-desc">
                            L'hôpital Eka est un hôpital général privé engagé à fournir des services de soins de santé de qualité par un personnel dévoué et professionnel.<br/>
                            Eka Hospital is a private general hospital committed to provide quality health care service from dedicated and professional staff 
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about-img">
                        <img src="/images/about/dents.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <section class="sections services">
        <div id="servis">
            <div class="container">
                <div class="section-header text-center">
                    <h2 class="section-title">Nos services</h2>
                    <div class="line"><span></span></div>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Fugiat adipisci animi, porro unde iusto
                        libero.</p>
                </div>
                <!--/sect header-->
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <div class="serv">
                            <i class="icon fa fa-heart fa-lg"></i>
                            <h3 class="serv-title">carr</h3>
                            <p class="serv-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur,
                                nostrum qui. Qui ex molestias minima!</p>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="serv">
                            <i class="icon fa fa-heart fa-lg"></i>
                            <h3 class="serv-title">Suivie</h3>
                            <p class="serv-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur,
                                nostrum qui. Qui ex molestias minima!</p>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="serv">
                            <i class="icon fa fa-medkit fa-lg"></i>
                            <h3 class="serv-title">Suivre l'état du patient à distance</h3>
                            <p class="serv-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur,
                                nostrum qui. Qui ex molestias minima!</p>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="serv">
                            <i class="icon fa fa-user-md fa-lg"></i>
                            <h3 class="serv-title">Dedicated and professional staff</h3>
                            <p class="serv-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur,
                                nostrum qui. Qui ex molestias minima!</p>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="serv">
                            <i class="icon fa fa-stethoscope fa-lg"></i>
                            <h3 class="serv-title">Haute technologie</h3>
                            <p class="serv-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur,
                                nostrum qui. Qui ex molestias minima!</p>
                        </div>
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="serv">
                            <i class="icon fa fa-ambulance fa-lg"></i>
                            <h3 class="serv-title">Ambulance</h3>
                            <p class="serv-desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur,
                                nostrum qui. Qui ex molestias minima!</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <div class="test"></div>

    <script src="js/vendors/jquery-3.5.1.min.js"></script>
    <script src="js/vendors/bootstrap.js"></script>
    <script src="js/main.js"></script>
</body>

</html>